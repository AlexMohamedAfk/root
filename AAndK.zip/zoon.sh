#!/system/bin/sh

su -c 'iptables --flush'
am force-stop com.tencent.ig
rm -rf /data/data/com.tencent.ig/app_crashrecord/*
rm -rf /data/data/com.tencent.ig/files/tss_tmp/*
rm -rf /data/user/0/com.tencent.ig/files/tss_tmp/*
rm -rf /data/user_de/0/com.tencent.ig/c*
rm -rf /data/data/com.tencent.ig/databases/bugly*
rm -rf /data/user/0/com.tencent.ig/shared_prefs/*
rm -rf /data/data/com.tencent.ig/shared_prefs/device_id.xml
echo "<?xml version='1.0' encoding='utf-8' standalone='yes' ?>
<map>
  <string name=\"random\"></string>
  <string name=\"install\"></string>
  <string name=\"uuid\">$RANDOM$RANDOM-$RANDOM-$RANDOM-$RANDOM-$RANDOM$RANDOM$RANDOM</string>
</map>" > /data/data/com.tencent.ig/shared_prefs/device_id.xml
rm -rf /data/system/users/0/settings_ssaid.xml
echo "all done by KawKab @ELPAPPA1"