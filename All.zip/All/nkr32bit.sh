#!/bin/bash

# دالة لعرض التاريخ وتنظيف الشاشة
function Mythic() {
    clear
    date
    echo -e "\n[\e[1;32m+\e[0m] بدء تشغيل السكربت..."
}

# دالة لإرسال إشعار
function send_notification() {
    title="$1"
    message="$2"

    if command -v termux-notification &> /dev/null; then
        termux-notification --title "$title" --content "$message"
    elif command -v notify-send &> /dev/null; then
        notify-send "$title" "$message"
    fi
}

# تشغيل صوت بسيط إن أمكن
function play_sound() {
    if command -v termux-media-player &> /dev/null; then
        termux-media-player play /system/media/audio/ui/KeypressStandard.ogg
    fi
}

# دالة التحميل والتشغيل
function antiban() {
    eval "$(pm dump $PKG | grep LibraryDir)"
    lib_dir=$legacyNativeLibraryDir
    arm=$(ls "$lib_dir" | grep arm)
    lib_path="$lib_dir/$arm"

    echo -e "\n[\e[1;34m...\e[0m] جاري التحقق من الملفات..."

    file_url="https://raw.githubusercontent.com/AlexMohamedAfk/root/main"
    tmp_dir="/data/local/tmp"

    mkdir -p "$tmp_dir"

    # تحميل ملف inj32
    if [ ! -f "$tmp_dir/Mythic" ]; then
        echo "[+] تحميل inj32..."
        wget -T 10 -O "$tmp_dir/Mythic" "$file_url/inj32"
        [ -f "$tmp_dir/Mythic" ] && chmod 755 "$tmp_dir/Mythic"
    fi

    # تحميل libAlex32.so
    if [ ! -f "$tmp_dir/libMythic.so" ]; then
        echo "[+] تحميل libAlex32.so..."
        wget -T 10 -O "$tmp_dir/libMythic.so" "$file_url/libAlex32.so"
        [ -f "$tmp_dir/libMythic.so" ] && chmod 755 "$tmp_dir/libMythic.so"
    fi

    # تحقق أن الملفات موجودة فعليًا
    if [ ! -f "$tmp_dir/Mythic" ] || [ ! -f "$tmp_dir/libMythic.so" ]; then
        echo "[!] فشل تحميل الملفات!"
        send_notification "MythicCheat" "فشل تحميل الملفات"
        exit 1
    fi

    echo -e "\n[\e[1;32m✓\e[0m] التحميل اكتمل!"
    send_notification "MythicCheat" "تم تحميل الملفات بنجاح"
    play_sound
    sleep 2

    echo -e "\n[\e[1;34m>\e[0m] تشغيل التطبيق..."
    am start -n "$PKG/com.epicgames.ue4.SplashActivity" &> /dev/null
    sleep 3

    echo "[*] بدء الحقن..."
    su -c "$tmp_dir/Mythic $PKG $tmp_dir/libMythic.so"

    # إذا أغلق التطبيق، حذف الملفات
    if ! pgrep -x "${PKG##*.}" > /dev/null; then
        echo -e "\n[\e[1;31m!\e[0m] التطبيق أغلق! جاري تنظيف الملفات..."
        rm -f "$tmp_dir/Mythic" "$tmp_dir/libMythic.so"
        send_notification "MythicCheat" "تم حذف الملفات بعد الإغلاق"
        exit
    fi
}

# المتغير الأساسي
PKG="com.pubg.krmobile"

# بدء التنفيذ
Mythic
antiban
